#include<stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>

bool isDivisible(int number);


int main()
{
	int i=0;
	for(i=20;!isDivisible(i);i++);
	printf("%d\n",i);
	return 0;
}

bool isDivisible(int number)
{
	int i=0;
	for(i=3;i<=20;i++)
	{
		if(number%i!=0)
		{
			return false;
		}
	}
	return true;
}
