#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>

#define LENGTH 800

int array[LENGTH]={0};
bool pythagorean(int a,int b,int c);
bool compare(int a,int b,int c);

int main()
{
	int i=0;
	for(i=0;i<LENGTH;i++)
	{
		array[i]=i*i;
	}
	//init
	int a=200,b=201,c=0;
	while(true)
	{
		bool tag=true;
		c=1000-a-b;
		if(!compare(a,b,c))
		  tag=false;
		if(!pythagorean(a,b,c))
		  tag=false;
		if(tag)
		  break;
		
		b++;
		if(!compare(a,b,c))
		{
			a++;
			b=a+1;
		}
		printf("%d %d %d\n",a,b,c);
	}
	printf("-----%d %d %d\n",a,b,c);
	return 0;
}
bool pythagorean(int a,int b,int c)
{
	a=array[a];
	b=array[b];
	c=array[c];
	return (a+b)==c;
}
bool compare(int a,int b,int c)
{
	return (a<b)&&(b<c);
}
