#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include"util.h"
#include<time.h>

#define LENGTH 20

int main()
{
	clock_t start,end;
	start=clock();
	FILE * f=fopen("context","r");
	if(NULL==f)
	  exit(1);
	unsigned int array[20][20];
	int i,j;
	for(i=0;i<LENGTH;i++)
	{
		for(j=0;j<LENGTH;j++)
		{
			fscanf(f,"%u",&array[i][j]);
		}
	}
	unsigned int max=0;
	int k=0;
	 for(i=0;i<LENGTH-3;i++)
	{
		for(j=0;j<LENGTH-3;j++)
		{
			unsigned int transverse=1;
			unsigned int vertical=1;
			unsigned int oblique=1;
			for(k=0;k<4;k++)
			{
				transverse*=array[i][j+k];
				vertical*=array[i+k][j];
				oblique*=array[i+k][j+k];
			}
			if(max<transverse)
			  max=transverse;
			if(max<vertical)
			  max=vertical;
			if(max<oblique)
			  max=oblique;
			//-------------------------------
			transverse=vertical=oblique=1;
			for(k=0;k<4;k++)
			{
				transverse*=array[19-i][19-j-k];
				vertical*=array[19-i-k][19-j];
				oblique*=array[19-i-k][19-j-k];
			}
			if(max<transverse)
			  max=transverse;
			if(max<vertical)
			  max=vertical;
			if(max<oblique)
			  max=oblique;
			//--------------------------------
			transverse=vertical=oblique=1;
			for(k=0;k<4;k++)
			{
				transverse*=array[19-i][j+k];
				vertical*=array[19-i-k][j];
				oblique*=array[19-i-k][j+k];
			}
			if(max<transverse)
			  max=transverse;
			if(max<vertical)
			  max=vertical;
			if(max<oblique)
			  max=oblique;
			//----------------------------------
			transverse=vertical=oblique=1;
			for(k=0;k<4;k++)
			{
				transverse*=array[i][19-j-k];
				vertical*=array[i+k][19-j];
				oblique*=array[i+k][19-j-k];
			}
			if(max<transverse)
			  max=transverse;
			if(max<vertical)
			  max=vertical;
			if(max<oblique)
			  max=oblique;
		}
	}
	end=clock();
	printf("%f\n",timing(end,start));
	printf("%u\n",max);
	return 0;
}
