#include<stdio.h>
#include<stdbool.h>
#define TARGET 600851475143
#define HALF 775147

bool isPrime(unsigned int  number)
{
	if(number==0||number==1||number==2)
	  return false;
	if(number%2==0)
	  return false;
	int i=0;
	for (i = 3; i*i <= number ; i+=2)
		if(number%i==0)
			return false;
	return true;
}

void init(unsigned short array[])
{
	int i=0;
	for(i=0;i<HALF;i++)
	{
		if(isPrime(i))
		{
			array[i]=1;
		}
		else
		{
			array[i]=0;
		}
	}
}

int main()
{
	unsigned short array[HALF];
	init(array);
	int i=0;
	int max=0;
	for(i=3;i<HALF;i+=2)
	{
		if(TARGET%i==0&&array[i])
		{
			max=i;
			printf("%d\n",max);
		}
	}
	return 0;
}
