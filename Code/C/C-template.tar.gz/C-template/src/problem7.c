#include<stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
#define LENGTH 110000
short array[LENGTH]={0};
int length=3;
int prime=0;

int main()
{
	//array[2]=-1;  //newly comfirmed prime tag is negative number
	//newly comfirmed non-prime number's tag is a positive number
	int i=0;
	for(i=2;i<length;i++)
	{
		if(array[i]==0)
		{
			array[i]--;
		}
		if(array[i]==-1)
		{
			array[i]--;
			prime++;
		}
		int j=0;
		for(j=2;j<LENGTH/i;j++)
		{
			int location=i*j;
			if(array[location]==0)
			{
				array[location]=1;
			}
			if(location>=length)
			{
				length=location+1;
			}
		}
	}
	int statistics=0;
	for(i=2;statistics<10001;i++)
	{
		if(array[i]<0)
		{
			statistics++;
		}
		//printf("%d\n",array[i-1]);
	}
	printf("%d\n",i-1);
	printf("%d\n",statistics);
	printf("%d\n",prime);
	return 0;
}
