#include<stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
bool isPalindrome(int number)
{
	char string[6];
	sprintf(string,"%d",number);
	printf("%s ",string);
	int length=strlen(string);
	int i=0;
	for(i=0;i<length/2;i++)
	{
		if(string[i]!=string[length-i-1])
		{
			return false;
		}
	}
	return true;
}

int main()
{
	int first=999,second=999;
	int result=0;
	int max=0;
	for(result=first*second;first>=100&&second>=100;)
	{
		if(isPalindrome(result))
		{
			if(max<result)
			{
				max=result;
			}
		}
		second--;
		if(second<100)
		{
			second=999;
			first--;
		}
		result=first*second;
	}
	printf("%d\n",max);
	return 0;
}
