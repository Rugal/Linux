#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>

#define LENGTH 2000000
short array[LENGTH]={0};
int   prime=0;

/*
unsigned int array[100][50]={0};
int main()
{
	FILE* f=fopen("context","r");
	if(NULL==f)
	  exit(1);
	int i,j;
	for(i=0;i<100;i++)
	{
		char temp;
		for(j=0;j<50;j++)
		  fscanf(f,"%c",&array[i][j]);
		fscanf(f,"%c",&temp);
	}
	for(j=0;j<50;j++)
	{
		unsigned int sum=0;
		for(i=0;i<100;i++)
		{
			sum+=array[i][j];
		}
	}
	return 0;
}
*/
int main()
{
	unsigned int i=0;
	unsigned int sum=0;
	clock_t start,end;
	array[2]=0;
	array[1]=array[1]=1;
	start=clock();
	for(i=2;i<LENGTH;i++)
	{
		if(0==array[i])
		{
		  array[i]=-10;
		  sum+=i;
		}
		int j=0;
		for(j=1;i*j<LENGTH;j++)
		  array[i*j]++;
	}
	end=clock();
	printf("%u\n",sum);
	printf("%f\n",timing(end,start));
	printf("Rugal Bernstein\n");
	return 0;
}
/*  
#include <stdio.h>
#include <math.h>

#define LIMIT 2000000

int bits[LIMIT/8 + 1];
#define GET_BIT(n) ((bits[n/8]>>(n%8))&1)
#define SET_BIT(n) (bits[n/8] |= 1 << (n%8))

int main() 
{
	int sqrt_lim = (int)(sqrtf(LIMIT)+1);
	long long sum=0;
	for (int i=2; i<LIMIT; i++) 
	{
		if (! GET_BIT(i)) 
		{ // Found a prime
				   printf("%d\n", i);
			sum += i;
			if (i<=sqrt_lim) for (int j=i*i; j<LIMIT; j+=i) 
			{
				SET_BIT(j);
			}
		}
	}
	printf("%lld\n", sum);
}
*/
