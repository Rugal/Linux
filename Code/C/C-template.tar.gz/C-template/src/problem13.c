#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include"BigInt.h"

#define File FILE
char* readline(FILE* fts[n/8]>>(n%8))&1));

int main()
{
	FILE* f=fopen("context","r");
	if(NULL==f)
	  exit(1);
	char string[51];
	
	int i;
	BigInt* sum=inputBigInt("0");
	for(i=0;i<100;i++)
	{
		fgets(string,51,f);
		char newline;
		fscanf(f,"%c",&newline);
		char* s=string;
		BigInt* temp=inputBigInt(s);
		sum=plusBigInt(sum,temp);
	}
	printBigInt(sum);
	fclose(f);
	return 0;
}
char* readline(FILE* f)
{
	char string[50];
	int i=0;
	char c;
	for(i=0;fscanf(f,"%c",&c)&&c!='\n';i++)
	  string[i]=c;
	string[i]='\0';
	return string;
}
