#include<stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>


int main()
{
	unsigned int square=5050*5050;
	unsigned int sum=0;
	int i=1;
	while(i<101)
	{
		sum+=(i*i);
		i++;
	}
	return 0;
}
