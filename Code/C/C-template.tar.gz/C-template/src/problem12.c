#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include<math.h>

#define LENGTH  200000000
short array[LENGTH]={0};
int   prime=0;

bool isTriangle(unsigned int number);

int main()
{
	unsigned int i=0;
	for(i=1;i<LENGTH;i++)
	{
		int j=0;
		for(j=1;i*j<LENGTH;j++)
		{
			int location=i*j;
			array[location]++;
		}
	}
	for(i=100000;i<LENGTH;i++)
	{
		if(array[i]>=500&&isTriangle(i))
		{
			printf("%u\n",i);
			break;
		}
	}
	printf("Rugal Bernstein\n");
	return 0;
}


bool isTriangle(unsigned int number)
{
	int base=(int)sqrt(number);
	while((base*base+base)<(number*2))
	  base++;
	if((base*base+base)==number*2)
	  return true;
	return false;
}
