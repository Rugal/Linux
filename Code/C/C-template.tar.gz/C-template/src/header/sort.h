#pragma once
#include"util.h"
TYPE* selection(TYPE* array,int length);
TYPE* insertion(TYPE* array,int length);
TYPE* shell(TYPE* array,int length);
TYPE* quick(TYPE* array,int length);
TYPE* merge(TYPE* array,int length);
TYPE* base(TYPE* array,int length);
TYPE* pile(TYPE* array,int length);
TYPE* bubble(TYPE* array,int length);
