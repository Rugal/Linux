void mergeSort(int array[],int length);
