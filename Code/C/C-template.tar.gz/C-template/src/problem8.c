#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
int main()
{
	FILE * f=fopen("context.txt","r");
	if(f==NULL)
	{
		exit(1);
	}
	char array[5];
	int count=0,max=-1000;
	int i=0;
	int current=1;
	/*printf("Rugal Bernstein\n");*/
	fscanf(f,"%c%c%c%c",&array[0],&array[1],&array[2],&array[3]);
	while(fscanf(f,"%c",&array[4])!=EOF)
	{
		current=1;
		for(i=0;i<5;i++)
		{
			current*=(array[i]-'0');
		}
		for(i=0;i<4;i++)
		{
			array[i]=array[i+1];
		}
		/*printf("%d ",current);*/
		if(current>max)
		{
			max=current;
		}
		count++;
		if(count%10==0)
		{
			fscanf(f,"%c",&array[4]);
		}
	}
	fclose(f);
	printf("%d\n",max);

	return 0;
}
